<?php
require_once FCPATH . 'vendor/autoload.php'; // Jika menggunakan Composer
// require_once APPPATH . 'third_party/dompdf/autoload.php'; // Jika tanpa Composer
use Dompdf\Dompdf;
