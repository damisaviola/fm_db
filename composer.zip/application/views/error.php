<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran Gagal</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>"> <!-- Tambahkan CSS sesuai kebutuhan -->
</head>
<body>
    <div class="container">
        <h1>Pembayaran Gagal</h1>
        <p>Maaf, pembayaran Anda gagal. Silakan coba lagi atau hubungi support kami jika diperlukan.</p>
        <a href="<?php echo site_url('subscription/choose_plan'); ?>" class="btn btn-primary">Kembali ke Pilihan Plan</a>
    </div>
</body>
</html>
