<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['midtrans_client_key'] = 'SB-Mid-client-k7-7SPyaBMDQAZFC';  // Ganti dengan Client Key Midtrans
$config['midtrans_server_key'] = 'SB-Mid-server-KClKjF4WF2RVmJsTr891CQcn';  // Ganti dengan Server Key Midtrans
$config['midtrans_is_production'] = false;  // Set ke true untuk mode produksi
$config['midtrans_is_sanitized'] = true;  // Set ke true untuk sanitasi input
$config['midtrans_is_3ds'] = true;  
